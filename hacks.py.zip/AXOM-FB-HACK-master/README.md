# AXOM-FB-HACK
#facebook hacking tool for termux or linux 2020
#Only use token for login or Dont use real id


FEATURES:
======================================
1 LOGIN WITH EMAIL/USR ID

 2 LOGIN WITH TOKEN

IFORMATIONS:
=======================================
 1 Facebook friend info fetcher

 2 Get ID from friend

 3 Get ID friend from friend

 4 Get group member ID

 5 Get email friend

 6 Get email friend from friend

 7 Get a friend's phone number

 8 Get a friend's phone number from friend

 9 Mini Hack Facebook(Target)

 10 Multi Bruteforce Facebook

 11 Super Multi Bruteforce Facebook

 12 BruteForce(Target)

 13 Yahoo Checker

 14 Bot Reactions Target Post

 15 Bot Reactions group Post

 16 BOT COMMENT Target Post

 17 BOT COMMENT group Post

 18 Mass delete Post

 19 Mass accept friends

 20 Mass delete friend

 21 ACreate Post

 22 Create Wordlist

 23 Account Checker

 24 See my group list

 25 Profile Guard



INSTALLATION:
============================================
$ apt update && apt upgrade

$ apt install git

$ apt install python2

$ git clone https://github.com/dAYOShACKER505/AXOM-FB-HACK

$ cd AXOM-FB-HACK

$ ls

$ python2 axom.py


DONATE ME                       
=================================================
BTC ADDRESS-                                                            
3NyAqCN5YvtXSCCxcAgr43uzugSqGLGYaK 

